/* HUMBLE Carousel — English only */
const I18N = (function () {
  const DICT = { en: {
      lang: "LANG",
      refresh: "Refresh",
      tab_styles: "STYLES", tab_media: "MEDIA", tab_text: "TEXT", tab_ctrl: "CONTROLS",
      opt_bg: "Background",
      opt_grain: "Grain (slower)",
      opt_fit: "Framing",
      fit_width: "Fit width — whole carousel",
      fit_height: "Fit height — filled",
      opt_zoom: "Zoom",
      target_checking: "checking active composition…",
      btn_build: "BUILD IN AE",
      btn_open_tpl: "OPEN TEMPLATE",
      tip_open_tpl: "Open the template separately",
      fill_all: "FILL ALL…",
      clear_all: "CLEAR",
      slot_clear: "clear",
      text_hint: "Text 1–10 — text compositions inside the template",
      ph_text: "text…",
      ph_missing: "not found",
      btn_load: "LOAD",
      ctrl_empty: "Build a style in STYLES first,<br>then press LOAD.",
      ctrl_reading: "reading controls…",
      ready: "ready",
      link_missing: "{title} link is not set",
      link_opened: "{title} opened",
      link_fail: "Link didn't open: {e}",
      style_picked: "{name} selected",
      building: "building {name}…",
      built_into: "done: {into}",
      slot_cleared: "Slot {n} cleared",
      slot_filled: "Slot {n} ← {name}",
      placing: "placing {n} files…",
      filled_n: "{n} slots filled",
      clearing: "clearing…",
      cleared_all: "all slots cleared",
      tpl_loaded: "TEMPLATE LOADED",
      tpl_missing: "TEMPLATE NOT FOUND",
      bridge_err: "BRIDGE ERROR",
      host_fail: "host.jsx failed to load (EvalScript error)",
      answer_fail: "Couldn't read the answer: ",
      js_err: "JS error: ",
      tpl_not_found: "Template not found: ",
      aep_missing: "assets/Carousel Pro 24.x.aep not found",
      enabled: "enabled"
    } };
  let lang = "en";
  function t(key, vars) {
    let s = DICT.en[key] != null ? DICT.en[key] : key;
    if (vars) for (const k in vars) s = s.split("{" + k + "}").join(vars[k]);
    return s;
  }
  function applyStatic(root) {
    (root || document).querySelectorAll("[data-i18n]").forEach(el => el.innerHTML = t(el.getAttribute("data-i18n")));
    (root || document).querySelectorAll("[data-i18n-title]").forEach(el => el.title = t(el.getAttribute("data-i18n-title")));
    (root || document).querySelectorAll("[data-i18n-ph]").forEach(el => el.placeholder = t(el.getAttribute("data-i18n-ph")));
    document.documentElement.setAttribute("lang", "en");
  }
  function onChange() {}
  function set() {}
  function get() { return lang; }
  function list() { return ["en"]; }
  return { t, set, get, list, applyStatic, onChange };
})();
const t = I18N.t;