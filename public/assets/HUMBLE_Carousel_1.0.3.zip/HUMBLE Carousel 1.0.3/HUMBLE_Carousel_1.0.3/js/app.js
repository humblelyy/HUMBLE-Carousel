/* ============================================================
   HUMBLE — CAROUSEL   ·   panel controller
   ============================================================ */


const NREQ = (function () {
  if (typeof require === 'function') return require;
  if (typeof window !== 'undefined' && window.cep_node && window.cep_node.require)
    return window.cep_node.require.bind(window.cep_node);
  return null;
})();

/* ── panel-side diagnostics log ─────────────────────────── */

const LOGPATH = (() => {
  try {
    const os = NREQ('os');
    return os.homedir() + '/Library/Application Support/CarouselPro/panel.log';
  } catch (e) { return null; }
})();

function plog(msg) {
  const line = `[${new Date().toISOString()}] ${msg}\n`;
  try {
    const fs = NREQ('fs'), path = NREQ('path');
    fs.mkdirSync(path.dirname(LOGPATH), { recursive: true });
    fs.appendFileSync(LOGPATH, line);
  } catch (e) { /* node yo'q — faqat konsolga */ }
  try { console.log(msg); } catch (e2) { }
}

window.onerror = (m, src, ln, col) => {
  plog(`JS XATO: ${m} @ ${src}:${ln}:${col}`);
  const el = document.getElementById('status');
  if (el) { el.textContent = t('js_err') + m; el.className = 'status err'; }
};

const cs = new CSInterface();
const $  = (s, r) => (r || document).querySelector(s);
const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));

/* ── bridge ─────────────────────────────────────────────── */

function call(payload) {
  return new Promise(resolve => {
    let enc;
    try { enc = encodeURIComponent(JSON.stringify(payload)); }
    catch (e) { plog('encode XATO: ' + e); return resolve({ ok: false, error: 'encode: ' + e }); }
    plog('-> ' + payload.op + ' ' + JSON.stringify(payload).slice(0, 200));
    let done = false;
    const guard = setTimeout(() => {
      if (!done) { plog('!! ' + payload.op + ' JAVOB YO‘Q (5s)'); resolve({ ok: false, error: payload.op + ': AE javob bermadi' }); }
    }, 5000);
    try {
      cs.evalScript(`CP_run("${enc}")`, res => {
        done = true; clearTimeout(guard);
        plog('<- ' + payload.op + ' ' + String(res).slice(0, 300));
        if (res === 'EvalScript error.' || res === undefined || res === '')
          return resolve({ ok: false, error: t('host_fail') });
        try { resolve(JSON.parse(res)); }
        catch (e) { resolve({ ok: false, error: t('answer_fail') + String(res).slice(0, 160) }); }
      });
    } catch (e) {
      done = true; clearTimeout(guard);
      plog('!! evalScript tashladi: ' + e);
      resolve({ ok: false, error: 'evalScript: ' + e });
    }
  });
}

let statusTimer = null;
function say(msg, kind) {
  const el = $('#status');
  el.textContent = msg;
  el.className = 'status' + (kind ? ' ' + kind : '');
  clearTimeout(statusTimer);
  if (kind === 'ok') statusTimer = setTimeout(() => { el.textContent = t('ready'); el.className = 'status'; }, 2600);
}



/* ── social links ───────────────────────────────────────── */
const LINKS = [
  { key: 'instagram', title: 'Instagram', url: 'https://www.instagram.com/_humble.y_/' },
  { key: 'youtube',   title: 'YouTube',   url: 'https://www.youtube.com/@humbleae' },
];


function buildSocial() {
  const wrap = $('#social');
  if (!wrap) return;
  wrap.innerHTML = '';
  LINKS.forEach(link => {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'social-btn';
    btn.title = link.title;
    btn.setAttribute('aria-label', link.title);
    btn.innerHTML = ICONS[link.key] || link.title;
    btn.onclick = () => {
      try {
        cs.openURLInDefaultBrowser(link.url);
        say(t('link_opened', { title: link.title }), 'ok');
      } catch (e) {
        say(t('link_fail', { e: String(e) }), 'err');
      }
    };
    wrap.appendChild(btn);
  });
}

const ICONS = {
  'instagram':  '<svg viewBox="0 0 24 24"><path d="M12 2.2c3.2 0 3.6 0 4.85.07 1.17.05 1.8.25 2.23.42.56.22.96.48 1.38.9.42.42.68.82.9 1.38.17.42.37 1.06.42 2.23.06 1.25.07 1.63.07 4.8s0 3.55-.07 4.8c-.05 1.17-.25 1.8-.42 2.23-.22.56-.48.96-.9 1.38-.42.42-.82.68-1.38.9-.42.17-1.06.37-2.23.42-1.25.06-1.63.07-4.85.07s-3.6 0-4.85-.07c-1.17-.05-1.8-.25-2.23-.42-.56-.22-.96-.48-1.38-.9-.42-.42-.68-.82-.9-1.38-.17-.42-.37-1.06-.42-2.23C2.2 15.55 2.2 15.17 2.2 12s0-3.55.07-4.8c.05-1.17.25-1.8.42-2.23.22-.56.48-.96.9-1.38.42-.42.82-.68 1.38-.9.42-.17 1.06-.37 2.23-.42C8.45 2.2 8.83 2.2 12 2.2zm0 1.95c-3.12 0-3.49.01-4.72.07-.9.04-1.39.19-1.71.32-.43.17-.74.37-1.06.69-.32.32-.52.63-.69 1.06-.13.32-.28.81-.32 1.71-.06 1.23-.07 1.6-.07 4.72s.01 3.49.07 4.72c.4.9.19 1.39.32 1.71.17.43.37.74.69 1.06.32.32.63.52 1.06.69.32.13.81.28 1.71.32 1.23.06 1.6.07 4.72.07s3.49-.01 4.72-.07c.9-.04 1.39-.19 1.71-.32.43-.17.74-.37 1.06-.69.32-.32.52-.63.69-1.06.13-.32.28-.81.32-1.71.06-1.23-.07-1.6-.07-4.72s.01-3.49.07-4.72c.04-.9.19-1.39.32-1.71a2.86 2.86 0 0 0-.69-1.06 2.86 2.86 0 0 0-1.06-.69c-.32-.13-.81-.28-1.71-.32-1.23-.06-1.6-.07-4.72-.07zm0 3.32a4.53 4.53 0 1 1 0 9.06 4.53 4.53 0 0 1 0-9.06zm0 7.47a2.94 2.94 0 1 0 0-5.88 2.94 2.94 0 0 0 0 5.88zm5.77-7.67a1.06 1.06 0 1 1-2.12 0 1.06 1.06 0 0 1 2.12 0z"/></svg>',
  'youtube':    '<svg viewBox="0 0 24 24"><path d="M23.5 6.9a3 3 0 0 0-2.12-2.12C19.5 4.27 12 4.27 12 4.27s-7.5 0-9.38.51A3 3 0 0 0 .5 6.9C0 8.78 0 12 0 12s0 3.22.5 5.1a3 3 0 0 0 2.12 2.12c1.88.51 9.38.51 9.38.51s7.5 0 9.38-.51a3 3 0 0 0 2.12-2.12C24 15.22 24 12 24 12s0-3.22-.5-5.1zM9.6 15.6V8.4l6.24 3.6-6.24 3.6z"/></svg>',
};
/* ── style catalogue ────────────────────────────────────── */

const STYLES = [
  { id:'01', key:'cy', name:'CYLINDER',   cards:10, note:'Rotating 3D cylinder' },
  { id:'02', key:'cb', name:'CUBE',       cards:4,  note:'4-sided cube'      },
  { id:'03', key:'fn', name:'FAN',        cards:10, note:'Fan-shaped arc'     },
  { id:'04', key:'rn', name:'RING',       cards:30, note:'30-card ring'   },
  { id:'05', key:'ps', name:'POLAROID',   cards:10, note:'Scattered Polaroid'    },
  { id:'06', key:'hx', name:'HELIX',      cards:10, note:'Spiral rise' },
  { id:'07', key:'sl', name:'SLIDE',      cards:10, note:'Horizontal slide'   },
  { id:'08', key:'rd', name:'RADIAL',     cards:10, note:'Radial rotation'    },
  { id:'09', key:'wb', name:'WAVE WALL',  cards:10, note:'Wave wall'    },
  { id:'10', key:'sn', name:'SNAP STACK', cards:10, note:'Stacked snap'     },
];

let selected = STYLES[0];
let env = { imported:false, comps:[], templateExists:false };

/* ── style previews (canvas) ────────────────────────────── */

function card(ctx, x, y, w, h, rot, alpha, fill) {
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(rot || 0);
  ctx.globalAlpha = Math.max(0.08, Math.min(1, alpha));
  ctx.fillStyle   = fill || '#3a3552';
  ctx.strokeStyle = '#8f7bff';
  ctx.lineWidth   = 0.9;
  ctx.beginPath();
  const r = Math.min(2.5, w / 4);
  ctx.moveTo(-w/2 + r, -h/2);
  ctx.arcTo( w/2, -h/2,  w/2,  h/2, r);
  ctx.arcTo( w/2,  h/2, -w/2,  h/2, r);
  ctx.arcTo(-w/2,  h/2, -w/2, -h/2, r);
  ctx.arcTo(-w/2, -h/2,  w/2, -h/2, r);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();
  ctx.restore();
}

const PREVIEW = {
  cy(c, t) {                                    // cylinder
    const n = 9, R = c.w * 0.36;
    const items = [];
    for (let i = 0; i < n; i++) {
      const a = (i / n) * Math.PI * 2 + t;
      items.push({ z: Math.cos(a), x: c.cx + Math.sin(a) * R, a });
    }
    items.sort((p, q) => p.z - q.z);
    items.forEach(p => {
      const s = 0.55 + 0.45 * (p.z + 1) / 2;
      card(c.g, p.x, c.cy, 11 * s, 17 * s, 0, 0.25 + 0.75 * s);
    });
  },
  cb(c, t) {                                    // cube
    const R = c.w * 0.24;
    const items = [];
    for (let i = 0; i < 4; i++) {
      const a = (i / 4) * Math.PI * 2 + t;
      items.push({ z: Math.cos(a), x: c.cx + Math.sin(a) * R, a });
    }
    items.sort((p, q) => p.z - q.z);
    items.forEach(p => {
      const s = 0.6 + 0.4 * (p.z + 1) / 2;
      card(c.g, p.x, c.cy, 22 * s, 24 * s, 0, 0.3 + 0.7 * s);
    });
  },
  fn(c, t) {                                    // fan
    const n = 9;
    for (let i = 0; i < n; i++) {
      const d = i - (n - 1) / 2;
      const a = d * 0.20;
      const s = 1 - Math.abs(d) * 0.07;
      card(c.g, c.cx + d * 9, c.cy + Math.abs(d) * 2.2, 12 * s, 18 * s, a, 1 - Math.abs(d) * 0.09);
    }
  },
  rn(c, t) {                                    // ring
    const n = 16, R = c.w * 0.33, RY = c.h * 0.17;
    const items = [];
    for (let i = 0; i < n; i++) {
      const a = (i / n) * Math.PI * 2 + t;
      items.push({ z: Math.cos(a), x: c.cx + Math.sin(a) * R, y: c.cy - Math.cos(a) * RY });
    }
    items.sort((p, q) => p.z - q.z);
    items.forEach(p => {
      const s = 0.45 + 0.55 * (p.z + 1) / 2;
      card(c.g, p.x, p.y, 8 * s, 12 * s, 0, 0.22 + 0.78 * s);
    });
  },
  ps(c, t) {                                    // polaroid scatter
    const n = 9, seed = [0.2,-0.6,0.9,-0.3,0.55,-0.85,0.4,-0.15,0.75];
    for (let i = 0; i < n; i++) {
      const a = (i / n) * Math.PI * 2 + t * 0.6;
      const R = c.w * (0.16 + 0.15 * Math.abs(seed[i]));
      card(c.g, c.cx + Math.cos(a) * R, c.cy + Math.sin(a) * R * 0.62,
           12, 15, seed[i] * 0.5, 0.55 + 0.45 * Math.abs(seed[i]));
    }
    card(c.g, c.cx, c.cy, 16, 20, 0, 1, '#4a4173');
  },
  hx(c, t) {                                    // helix
    const n = 11, R = c.w * 0.24;
    const items = [];
    for (let i = 0; i < n; i++) {
      const a = i * 0.72 + t;
      items.push({ z: Math.cos(a), x: c.cx + Math.sin(a) * R,
                   y: c.h * 0.86 - (i / (n - 1)) * c.h * 0.72 });
    }
    items.sort((p, q) => p.z - q.z);
    items.forEach(p => {
      const s = 0.55 + 0.45 * (p.z + 1) / 2;
      card(c.g, p.x, p.y, 11 * s, 8 * s, 0, 0.3 + 0.7 * s);
    });
  },
  sl(c, t) {                                    // slide
    const n = 7;
    for (let i = n - 1; i >= 0; i--) {
      const d = i - (n - 1) / 2;
      const s = 1 - Math.abs(d) * 0.13;
      card(c.g, c.cx + d * 17, c.cy, 14 * s, 21 * s, 0, 1 - Math.abs(d) * 0.22);
    }
  },
  rd(c, t) {                                    // radial
    const n = 10, R = c.h * 0.30;
    for (let i = 0; i < n; i++) {
      const a = (i / n) * Math.PI * 2 + t;
      card(c.g, c.cx + Math.cos(a) * R * 1.5, c.cy + Math.sin(a) * R,
           9, 13, a + Math.PI / 2, 0.5 + 0.5 * Math.abs(Math.cos(a)));
    }
  },
  wb(c, t) {                                    // wave bend wall
    const n = 9;
    for (let i = 0; i < n; i++) {
      const d = i - (n - 1) / 2;
      const y = c.cy + Math.sin(d * 0.8 + t) * 8;
      const s = 1 - Math.abs(d) * 0.075;
      card(c.g, c.cx + d * 11, y, 9 * s, 15 * s, d * 0.09, 0.4 + 0.6 * s);
    }
  },
  sn(c, t) {                                    // snap stack
    const n = 7;
    for (let i = n - 1; i >= 0; i--) {
      const s = 1 - i * 0.06;
      card(c.g, c.cx + i * 3.5, c.cy - i * 2.4, 24 * s, 30 * s, i * 0.035, 1 - i * 0.11);
    }
  },
};

function paintStyleCanvas(cv, key, t) {
  const g = cv.getContext('2d');
  const w = cv.width, h = cv.height;
  g.clearRect(0, 0, w, h);
  const grd = g.createLinearGradient(0, 0, 0, h);
  grd.addColorStop(0, '#151320'); grd.addColorStop(1, '#0d0c12');
  g.fillStyle = grd; g.fillRect(0, 0, w, h);
  (PREVIEW[key] || PREVIEW.sl)({ g, w, h, cx: w / 2, cy: h / 2 }, t);
}

/* animate previews */
let animT = 0, animRaf = null;
function tickPreviews() {
  animT += 0.014;
  $$('#styleGrid canvas').forEach(cv => paintStyleCanvas(cv, cv.dataset.key, animT));
  animRaf = requestAnimationFrame(tickPreviews);
}

function buildStyleGrid() {
  const grid = $('#styleGrid');
  grid.innerHTML = '';
  STYLES.forEach(s => {
    const el = document.createElement('div');
    el.className = 'card' + (s === selected ? ' on' : '');
    el.dataset.id = s.id;
    el.innerHTML =
      `<canvas width="150" height="74" data-key="${s.key}"></canvas>` +
      `<div class="nm">${s.id} · ${s.name}</div>` +
      `<div class="mt">${s.cards} karta · ${s.note}</div>`;
    el.onclick = () => {
      selected = s;
      $$('#styleGrid .card').forEach(c => c.classList.toggle('on', c.dataset.id === s.id));
      say(t('style_picked', {name: s.name}));
    };
    el.ondblclick = doBuild;
    grid.appendChild(el);
  });
  if (!animRaf) tickPreviews();
}

/* ── STYLES: build ──────────────────────────────────────── */

async function doBuild() {
  const btn = $('#btnBuild');
  btn.disabled = true;
  say(t('building', {name: selected.name}));
  const r = await call({
    op: 'build',
    style: selected.id,
    background: $('#optBg').checked,
    grain: $('#optGrain').checked,
    fit: $('#optFit').value,
  });
  btn.disabled = false;
  if (!r.ok) return say(r.error, 'err');
  say(r.into
        ? `${r.comp} → ${r.into} · ${r.reframe}`
        : `${r.comp} opened · ${r.width}×${r.height}`, 'ok');
  $('#optZoom').value = 100;
  $('#optZoomVal').textContent = '100%';
  await refreshEnv();
  await loadTexts();
  await loadMedia();
  $('#compSel').value = r.comp;
  loadControls();
}

/* qayerga qurilishini ko'rsatib turamiz */
async function refreshTarget() {
  const r = await call({ op: 'active' });
  const el = $('#targetInfo');
  if (!r.ok) { el.textContent = r.error; return; }
  el.innerHTML = r.active
    ? `Joylanadi: <b>${r.active}</b> — ${r.width}×${r.height} (karusel shu o‘lchamga moslanadi)`
    : `Aktiv kompozitsiya yo‘q — karusel alohida ochiladi. AE'da o‘z kompozitsiyangizni oching.`;
}

/* ── MEDIA ──────────────────────────────────────────────── */

let mediaSlots = [];

function renderMedia() {
  const grid = $('#slotGrid');
  grid.innerHTML = '';
  let filled = 0;
  mediaSlots.forEach(s => {
    const el = document.createElement('div');
    el.className = 'slot' + (s.filled ? ' filled' : '') + (s.exists ? '' : ' missing');
    el.innerHTML = `<span>${s.filled ? '✔' : s.n}</span>` +
                   `<span class="x" title="${I18N.t('slot_clear')}">×</span>` +
                   (s.filled ? `<span class="lbl">${s.name.slice(0, 11)}</span>` : '');
    if (s.filled) filled++;
    if (s.exists) {
      el.onclick = async ev => {
        if (ev.target.classList.contains('x')) {
          const r = await call({ op: 'clearMedia', n: s.n });
          if (!r.ok) return say(r.error, 'err');
          say(t('slot_cleared', {n: s.n}), 'ok');
          return loadMedia();
        }
        const p = await call({ op: 'pickFiles' });
        if (!p.ok || !p.paths.length) return;
        const r = await call({ op: 'setMedia', n: s.n, path: p.paths[0] });
        if (!r.ok) return say(r.error, 'err');
        say(t('slot_filled', {n: s.n, name: r.name}), 'ok');
        loadMedia();
      };
    }
    grid.appendChild(el);
  });
  $('#mediaCount').textContent = `${filled} / 30`;
}

async function loadMedia() {
  const r = await call({ op: 'readMedia' });
  if (!r.ok) { mediaSlots = []; return say(r.error, 'err'); }
  mediaSlots = r.slots;
  renderMedia();
}

async function fillAll() {
  const p = await call({ op: 'pickFiles' });
  if (!p.ok || !p.paths.length) return;
  say(t('placing', {n: p.paths.length}));
  const r = await call({ op: 'fillAll', paths: p.paths, start: 1 });
  if (!r.ok) return say(r.error, 'err');
  say(t('filled_n', {n: r.filled}), 'ok');
  loadMedia();
}

async function clearAll() {
  say(t('clearing'));
  for (const s of mediaSlots) if (s.filled) await call({ op: 'clearMedia', n: s.n });
  say(t('cleared_all'), 'ok');
  loadMedia();
}

/* ── TEXT ───────────────────────────────────────────────── */

async function loadTexts() {
  const r = await call({ op: 'readTexts' });
  const list = $('#textList');
  list.innerHTML = '';
  if (!r.ok) return say(r.error, 'err');
  r.texts.forEach(t => {
    const row = document.createElement('div');
    row.className = 'trow';
    row.innerHTML = `<span class="n">TXT ${t.n}</span><input type="text" value="">`;
    const inp = $('input', row);
    inp.value = t.text;
    inp.disabled = !t.exists;
    inp.placeholder = t.exists ? I18N.t('ph_text') : I18N.t('ph_missing');
    let tmr = null;
    const push = async () => {
      const r2 = await call({ op: 'setText', n: t.n, text: inp.value });
      say(r2.ok ? `Text ${t.n} updated` : r2.error, r2.ok ? 'ok' : 'err');
    };
    inp.oninput = () => { clearTimeout(tmr); tmr = setTimeout(push, 450); };
    inp.onchange = () => { clearTimeout(tmr); push(); };
    list.appendChild(row);
  });
}

/* ── CONTROLS (dynamic) ─────────────────────────────────── */

const hex = v => '#' + v.map(x => Math.round(Math.max(0, Math.min(1, x)) * 255)
                                    .toString(16).padStart(2, '0')).join('');
const unhex = h => [1, 3, 5].map(i => parseInt(h.substr(i, 2), 16) / 255);

/* pick a sensible slider range for an unknown control */
function rangeFor(label, v) {
  const L = label.toLowerCase();
  if (/visible cards|item number|center card|target number|random seed|shuffle/.test(L)) return [0, 30, 1];
  if (/global slider|start offset|control time/.test(L))                                 return [0, 1000, 1];
  if (/opacity|fade|blend|amount|intensity|min|falloff/.test(L))                         return [0, 100, 0.5];
  if (/rotation|angle|tilt|arc|spin|orbit|spiral|bend/.test(L))                          return [-360, 360, 1];
  if (/scale/.test(L))                                                                   return [0, 300, 1];
  if (/roundness|border|width|height|radius|depth|step|rise|spacing|range|distance|shift/.test(L))
                                                                                          return [0, Math.max(500, Math.abs(v) * 3), 1];
  const m = Math.max(100, Math.abs(v) * 3);
  return v < 0 ? [-m, m, 0.5] : [0, m, 0.5];
}

function ctlRow(comp, it) {
  const wrap = document.createElement('div');

  if (it.kind === 'header') {
    wrap.className = 'sec';
    wrap.textContent = it.label;
    return wrap;
  }

  const send = (type, value) => call({
    op: 'set', comp, layer: it.layer, fx: it.fx, idx: it.idx, type, value
  }).then(r => { if (!r.ok) say(r.error, 'err'); });

  if (it.kind === 'color') {
    wrap.className = 'ctl row';
    wrap.innerHTML = `<span class="lab" style="display:block">${it.label}</span>`;
    const inp = document.createElement('input');
    inp.type = 'color';
    inp.value = hex(it.value);
    inp.oninput = () => send('color', unhex(inp.value));
    wrap.appendChild(inp);
    return wrap;
  }

  if (it.kind === 'check') {
    wrap.className = 'ctl row';
    wrap.innerHTML = `<span class="lab" style="display:block">${it.label}</span>`;
    const inp = document.createElement('input');
    inp.type = 'checkbox';
    inp.checked = !!it.value;
    inp.onchange = () => send('check', inp.checked);
    wrap.appendChild(inp);
    return wrap;
  }

  if (it.kind === 'point') {
    wrap.className = 'ctl';
    wrap.innerHTML = `<div class="lab"><span>${it.label}</span></div>`;
    const box = document.createElement('div');
    box.style.display = 'flex'; box.style.gap = '6px';
    const mk = i => {
      const n = document.createElement('input');
      n.type = 'number'; n.step = '1'; n.value = it.value[i];
      n.onchange = () => send('point', [+$$('input', box)[0].value, +$$('input', box)[1].value]);
      return n;
    };
    box.appendChild(mk(0)); box.appendChild(mk(1));
    wrap.appendChild(box);
    return wrap;
  }

  // slider / angle
  const [min, max, step] = it.kind === 'angle' ? [-360, 360, 1] : rangeFor(it.label, it.value);
  wrap.className = 'ctl';
  wrap.innerHTML =
    `<div class="lab"><span>${it.label}</span>` +
    `<input type="number" step="${step}" value="${it.value}"></div>` +
    `<input type="range" min="${min}" max="${max}" step="${step}" value="${it.value}">`;
  const num = $('input[type=number]', wrap);
  const rng = $('input[type=range]', wrap);
  let tmr = null;
  const push = v => { clearTimeout(tmr); tmr = setTimeout(() => send('slider', v), 40); };
  rng.oninput   = () => { num.value = rng.value; push(+rng.value); };
  num.onchange  = () => {
    const v = +num.value;
    if (v < +rng.min) rng.min = v;
    if (v > +rng.max) rng.max = v;
    rng.value = v; push(v);
  };
  return wrap;
}

async function loadControls() {
  const comp = $('#compSel').value;
  const body = $('#ctrlBody');
  if (!comp) {
    body.innerHTML = '<div class="empty">' + t('ctrl_empty') + '</div>';
    return;
  }
  say(t('ctrl_reading'));
  const r = await call({ op: 'controls', comp });
  if (!r.ok) { body.innerHTML = `<div class="empty">${r.error}</div>`; return say(r.error, 'err'); }
  body.innerHTML = '';
  let count = 0;
  r.groups.forEach(g => {
    const box = document.createElement('div');
    box.className = 'grp';
    const title = document.createElement('div');
    title.className = 'gt';
    title.textContent = g.layer;
    box.appendChild(title);
    g.items.forEach(it => { box.appendChild(ctlRow(comp, it)); if (it.kind !== 'header') count++; });
    body.appendChild(box);
  });
  say(`${count} controls loaded`, 'ok');
}

/* ── env / boot ─────────────────────────────────────────── */

async function refreshEnv() {
  const r = await call({ op: 'env' });
  if (!r.ok) return say(r.error, 'err');
  env = r;
  const sel = $('#compSel');
  const keep = sel.value;
  sel.innerHTML = '';
  if (!r.comps.length) {
    const o = document.createElement('option');
    o.textContent = '— not built yet —'; o.value = '';
    sel.appendChild(o);
  } else {
    r.comps.forEach(c => {
      const o = document.createElement('option');
      o.value = c; o.textContent = c;
      sel.appendChild(o);
    });
    sel.value = r.comps.includes(keep) ? keep
              : (r.comps.includes(r.active) ? r.active : r.comps[0]);
  }
  $('#subline').textContent = r.imported ? t('tpl_loaded') :
                              (r.templateExists ? 'HUMBLE' : t('tpl_missing'));
  if (!r.templateExists) say(t('aep_missing'), 'err');
  return r;
}

/* tabs */
$$('.tab').forEach(t => t.onclick = () => {
  $$('.tab').forEach(x => x.classList.toggle('on', x === t));
  $$('.page').forEach(p => p.classList.toggle('on', p.id === 'page-' + t.dataset.tab));
  if (t.dataset.tab === 'styles') refreshTarget();
  if (t.dataset.tab === 'media') loadMedia();
  if (t.dataset.tab === 'text')  loadTexts();
  if (t.dataset.tab === 'ctrl' && $('#compSel').value && !$('#ctrlBody').querySelector('.grp')) loadControls();
});

$('#btnBuild').onclick    = doBuild;
$('#btnOpenTpl').onclick  = async () => {
  const r = await call({ op: 'openTemplate' });
  say(r.ok ? 'Template opened' : r.error, r.ok ? 'ok' : 'err');
};
$('#btnRefresh').onclick  = async () => { await refreshEnv(); await refreshTarget(); say('Refreshed', 'ok'); };
$('#btnReload').onclick   = loadControls;
$('#compSel').onchange    = loadControls;
$('#btnFillAll').onclick  = fillAll;
$('#optFit').onchange     = () => say('Framing: ' + $('#optFit').selectedOptions[0].text);
{
  let zt = null;
  const z = $('#optZoom');
  z.oninput = () => {
    $('#optZoomVal').textContent = z.value + '%';
    const comp = $('#compSel').value;
    if (!comp) return;
    clearTimeout(zt);
    zt = setTimeout(async () => {
      const r = await call({ op: 'zoom', comp, pct: +z.value });
      if (!r.ok) say(r.error, 'err');
    }, 60);
  };
}
['optBg', 'optGrain'].forEach(id => {
  $('#' + id).onchange = async () => {
    const comp = $('#compSel').value;
    if (!comp) return;                                  // hali qurilmagan
    const layer = id === 'optBg' ? 'Background' : 'grain';
    const r = await call({ op: 'toggleLayer', comp, layer, on: $('#' + id).checked });
    say(r.ok ? `${layer}: ${r.on ? 'enabled' : 'disabled'}` : r.error, r.ok ? 'ok' : 'err');
  };
});
$('#btnClearAll').onclick = clearAll;

plog('=== PANEL BOOT ===');
plog('node=' + (typeof require === 'function') +
     ' cep=' + (typeof window.__adobe_cep__ !== 'undefined') +
     ' ext=' + (() => { try { return cs.getSystemPath(SystemPath.EXTENSION); } catch (e) { return 'N/A'; } })());

I18N.applyStatic();
buildSocial();
buildStyleGrid();

(async () => {
  // extension papkasini paneldan beramiz — host tomonda $.fileName ishonchsiz
  let root = '';
  try { root = cs.getSystemPath(SystemPath.EXTENSION); } catch (e) { plog('getSystemPath: ' + e); }
  plog('extension root = ' + root);

  const init = await call({ op: 'init', root });
  plog('INIT natijasi: ' + JSON.stringify(init));
  if (!init.ok) {
    say('BRIDGE DISCONNECTED — ' + init.error, 'err');
    $('#subline').textContent = t('bridge_err');
    return;
  }
  if (!init.templateExists) {
    say(t('tpl_not_found') + init.template, 'err');
    $('#subline').textContent = t('tpl_missing');
  }
  await call({ op: 'ping' });
  await refreshEnv();
  await refreshTarget();
})();
