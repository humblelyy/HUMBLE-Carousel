﻿/*
 * HUMBLE — CAROUSEL
 * ExtendScript host layer (ES3 safe — no let/const/arrow/forEach)
 * Single entry point: CP_run(encodedJson) -> JSON string
 */

// ─────────────────────────────────────────── utils

function cpEsc(s) {
    s = String(s);
    var out = "", i, c, code;
    for (i = 0; i < s.length; i++) {
        c = s.charAt(i);
        code = s.charCodeAt(i);
        if (c === '"') out += '\\"';
        else if (c === "\\") out += "\\\\";
        else if (c === "\n") out += "\\n";
        else if (c === "\r") out += "\\r";
        else if (c === "\t") out += "\\t";
        else if (code < 32 || code > 126) {
            var h = code.toString(16);
            while (h.length < 4) h = "0" + h;
            out += "\\u" + h;
        } else out += c;
    }
    return out;
}

function cpQ(s) { return '"' + cpEsc(s) + '"'; }

function cpNum(n) {
    if (n === null || isNaN(n)) return "0";
    return String(Math.round(n * 10000) / 10000);
}

function cpOk(bodyJson) { return '{"ok":true,' + bodyJson + "}"; }
function cpErr(msg) { return '{"ok":false,"error":' + cpQ(msg) + "}"; }

function cpArr(list) { return "[" + list.join(",") + "]"; }

// ─────────────────────────────────────────── paths

/* $.fileName faqat fayl yuklanayotganda to'g'ri bo'ladi — evalScript ichida bo'sh.
   Shuning uchun yo'lni shu yerda, yuklanish paytida qulflab qo'yamiz. */
var CP_ROOT = "";
try { CP_ROOT = File($.fileName).parent.parent.fsName; } catch (eRootBoot) { CP_ROOT = ""; }

function cpRoot() {
    if (CP_ROOT) return CP_ROOT;
    try { CP_ROOT = File($.fileName).parent.parent.fsName; } catch (eR) { }
    if (!CP_ROOT) throw new Error("Extension papkasi aniqlanmadi — panel 'init' yubormagan");
    return CP_ROOT;
}

/* Panel CSInterface.getSystemPath(EXTENSION) qiymatini shu yerga beradi —
   eng ishonchli manba. */
function cpOpInit(args) {
    if (args.root) {
        var d = new Folder(args.root);
        if (d.exists) CP_ROOT = d.fsName;
    }
    var f = null, ex = false;
    try { f = cpTemplateFile(); ex = f.exists; } catch (eT) { }
    cpLog("INIT root=" + CP_ROOT + " template=" + (f ? f.fsName : "?") + " exists=" + ex);
    return cpOk('"root":' + cpQ(CP_ROOT) +
                ',"template":' + cpQ(f ? f.fsName : "") +
                ',"templateExists":' + (ex ? "true" : "false"));
}

function cpTemplateFile() {
    var major = 24;
    try { major = parseInt(String(app.version).split(".")[0], 10); } catch (eV) { major = 24; }

    // The panel can load in older AE versions, but the supplied AEP templates
    // are only available for AE 2022+.
    var name = (major >= 24)
        ? "Carousel Pro 24.x.aep"
        : "Carousel Pro 24.x_converted_2022.aep";

    var f = new File(cpRoot() + "/assets/" + name);
    if (f.exists) return f;

    // fallback: next to the extension root (older layout)
    return new File(cpRoot() + "/" + name);
}

function cpRequireCompatibleTemplate() {
    var major = 24;
    try { major = parseInt(String(app.version).split(".")[0], 10); } catch (eV) { major = 24; }
    if (major < 22) {
        throw new Error("HUMBLE Carousel: the included templates require After Effects 2022 or newer. The panel can load in AE 2020, but this template build cannot.");
    }
}


// ─────────────────────────────────────────── diagnostics log

function cpLogFile() {
    var d = new Folder(Folder.userData.fsName + "/CarouselPro");
    if (!d.exists) d.create();
    return new File(d.fsName + "/host.log");
}

function cpLog(msg) {
    try {
        var f = cpLogFile();
        f.encoding = "UTF-8";
        f.open("a");
        f.writeln("[" + new Date().toString() + "] " + msg);
        f.close();
    } catch (e) { }
}

function cpSelfTest() {
    var lines = [];
    lines.push("host.jsx yuklandi");
    lines.push("app.version=" + app.version);
    lines.push("$.fileName=" + $.fileName);
    try { lines.push("root=" + cpRoot()); } catch (e1) { lines.push("root XATO: " + e1.toString()); }
    try {
        var f = cpTemplateFile();
        lines.push("template=" + f.fsName + " exists=" + f.exists);
    } catch (e2) { lines.push("template XATO: " + e2.toString()); }
    try { lines.push("numItems=" + app.project.numItems + " imported=" + cpIsImported()); }
    catch (e3) { lines.push("project XATO: " + e3.toString()); }
    lines.push("dash-test=" + ("\u2500\u2500 CYLINDER \u2500\u2500".indexOf("\u2500\u2500") === 0));
    cpLog("=== SELF TEST ===\n  " + lines.join("\n  "));
    return lines.join(" | ");
}

// ─────────────────────────────────────────── project search

function cpAllItems() {
    var out = [], i;
    for (i = 1; i <= app.project.numItems; i++) out.push(app.project.item(i));
    return out;
}

function cpFindComp(name) {
    var i, it, found = null;
    for (i = 1; i <= app.project.numItems; i++) {
        it = app.project.item(i);
        if (it instanceof CompItem && it.name === name) found = it;
    }
    return found;
}

function cpFindFolder(name) {
    var i, it;
    for (i = 1; i <= app.project.numItems; i++) {
        it = app.project.item(i);
        if (it instanceof FolderItem && it.name === name) return it;
    }
    return null;
}

function cpLayerByName(comp, name) {
    var i;
    for (i = 1; i <= comp.numLayers; i++) if (comp.layer(i).name === name) return comp.layer(i);
    return null;
}

// ─────────────────────────────────────────── template import

function cpIsImported() {
    return cpFindComp("Dynamic Carousel 01") !== null;
}

function cpEnsureTemplate() {
    if (cpIsImported()) return true;
    cpRequireCompatibleTemplate();
    var f = cpTemplateFile();
    if (!f.exists) throw new Error("Template topilmadi: " + f.fsName);
    if (!app.project) app.newProject();
    var io = new ImportOptions();
    io.file = f;
    try {
        if (io.canImportAs(ImportAsType.PROJECT)) io.importAs = ImportAsType.PROJECT;
    } catch (eIA) { }
    app.project.importFile(io);
    if (!cpIsImported()) throw new Error("Template import bo'ldi, lekin 'Dynamic Carousel 01' topilmadi");
    return true;
}

// ─────────────────────────────────────────── effect reading

function cpEffectsOf(layer) {
    try { return layer.property("ADBE Effect Parade"); } catch (e) { return null; }
}

/* Returns a JSON object string describing one effect control, or "" to skip */
function cpEffectJson(compName, layerName, fx, idx) {
    var mn = "", nm = "";
    try { mn = fx.matchName; nm = fx.name; } catch (e) { return ""; }

    // section separator: name looks like ── TITLE ──
    if (nm.indexOf("\u2500\u2500") === 0 || nm.indexOf("--") === 0) {
        var clean = nm;
        while (clean.indexOf("\u2500") >= 0) clean = clean.replace("\u2500", "");
        return '{"kind":"header","label":' + cpQ(cpTrim(clean)) + "}";
    }

    var base = '"layer":' + cpQ(layerName) + ',"fx":' + cpQ(nm) + ',"idx":' + idx + ',"label":' + cpQ(nm);

    if (mn === "ADBE Slider Control") {
        var v = 0;
        try { v = fx.property(1).value; } catch (e2) { }
        return '{"kind":"slider",' + base + ',"value":' + cpNum(v) + "}";
    }
    if (mn === "ADBE Angle Control") {
        var a = 0;
        try { a = fx.property(1).value; } catch (e3) { }
        return '{"kind":"angle",' + base + ',"value":' + cpNum(a) + "}";
    }
    if (mn === "ADBE Checkbox Control") {
        var b = false;
        try { b = fx.property(1).value; } catch (e4) { }
        return '{"kind":"check",' + base + ',"value":' + (b ? "true" : "false") + "}";
    }
    if (mn === "ADBE Color Control") {
        var c = [0, 0, 0];
        try { c = fx.property(1).value; } catch (e5) { }
        return '{"kind":"color",' + base + ',"value":' + cpArr([cpNum(c[0]), cpNum(c[1]), cpNum(c[2])]) + "}";
    }
    if (mn === "ADBE Point Control") {
        var p = [0, 0];
        try { p = fx.property(1).value; } catch (e6) { }
        return '{"kind":"point",' + base + ',"value":' + cpArr([cpNum(p[0]), cpNum(p[1])]) + "}";
    }
    return "";
}

function cpTrim(s) {
    s = String(s);
    while (s.length && (s.charAt(0) === " " || s.charAt(0) === "\t")) s = s.substring(1);
    while (s.length && (s.charAt(s.length - 1) === " " || s.charAt(s.length - 1) === "\t")) s = s.substring(0, s.length - 1);
    return s;
}

function cpEndsWith(s, suf) {
    return s.length >= suf.length && s.substring(s.length - suf.length) === suf;
}

/* Which layers of a carousel comp carry user-facing controls */
function cpIsControlLayer(name) {
    return cpEndsWith(name, "_Control") || cpEndsWith(name, "_Build") ||
        cpEndsWith(name, "_Effector") || name === "Options" || name === "Animation";
}


function cpIsTemplateComp(name) {
    return name.indexOf("Dynamic Carousel ") === 0 ||
           name.indexOf("Carousel Pro ") === 0 ||
           name.indexOf("Placeholder ") === 0 ||
           name.indexOf("Text ") === 0 ||
           name.indexOf("PreComp ") === 0 ||
           name.indexOf("PL PreComp ") === 0 ||
           name === "Background" || name === "Design Frame" || name === "grain" ||
           name === "Matte inner Frame" || name === "Media Holder Complexx";
}

/* Karusel komp ichidagi og'ir/keraksiz qatlamlarni yoqib-o'chirish */
function cpSetLayerEnabled(comp, layerName, on) {
    var lyr = cpLayerByName(comp, layerName);
    if (!lyr) return false;
    lyr.enabled = on;
    return true;
}

// ─────────────────────────────────────────── operations

function cpOpEnv() {
    var f = cpTemplateFile();
    var comps = [], i, it;
    for (i = 1; i <= app.project.numItems; i++) {
        it = app.project.item(i);
        if (it instanceof CompItem && (it.name.indexOf("Carousel Pro ") === 0 || it.name.indexOf("Dynamic Carousel ") === 0)) comps.push(cpQ(it.name));
    }
    var active = "";
    try { if (app.project.activeItem && app.project.activeItem instanceof CompItem) active = app.project.activeItem.name; } catch (e) { }
    return cpOk('"template":' + cpQ(f.fsName) +
        ',"templateExists":' + (f.exists ? "true" : "false") +
        ',"imported":' + (cpIsImported() ? "true" : "false") +
        ',"comps":' + cpArr(comps) +
        ',"active":' + cpQ(active) +
        ',"aeVersion":' + cpQ(app.version));
}

/* Karusel rigi 3840x2160 uchun qurilgan. Kompozitsiya o'lchamini o'zgartirganda
   kamera zoom'i va markazdagi qatlamlarni ham moslash SHART — aks holda 4K sahnaning
   burchagi qirqilib ko'rinadi. */
var CP_RIG = ["Carousel Orbit Y", "Background", "grain"];

function cpReframe(comp, W, H, fit) {
    var ow = comp.width, oh = comp.height;
    if (ow === W && oh === H) return "o'zgarishsiz " + W + "x" + H;

    var i, j, L, tg, p, moved = [];
    /* eski markazda turgan rig qatlamlarini eslab qolamiz */
    for (i = 1; i <= comp.numLayers; i++) {
        L = comp.layer(i);
        for (j = 0; j < CP_RIG.length; j++) {
            if (L.name === CP_RIG[j]) { moved.push(L); break; }
        }
    }

    comp.width = W;
    comp.height = H;

    for (i = 0; i < moved.length; i++) {
        L = moved[i];
        tg = L.property("ADBE Transform Group");
        p = tg.property("ADBE Position").value;
        tg.property("ADBE Position").setValue(
            p.length > 2 ? [W / 2, H / 2, p[2]] : [W / 2, H / 2]);

        /* to'liq kadrli manbalar (Background, grain) yangi kadrni qoplasin */
        try {
            if (L.source && L.source.width > 0 && L.name !== "Carousel Orbit Y") {
                var sc = Math.max(W / L.source.width, H / L.source.height) * 100;
                tg.property("ADBE Scale").setValue([sc, sc]);
            }
        } catch (eSc) { }
    }

    /* kamera: kadrlashni saqlash uchun zoom'ni proporsional o'zgartiramiz */
    var k = (fit === "height") ? (H / oh) : (W / ow);
    for (i = 1; i <= comp.numLayers; i++) {
        L = comp.layer(i);
        if (!(L instanceof CameraLayer)) continue;
        try {
            var zp = L.property("ADBE Camera Options Group").property("ADBE Camera Zoom");
            var nz = zp.value * k;
            zp.setValue(nz);
            try { comp.comment = "CP_BASEZOOM:" + nz; } catch (eC) { }
        } catch (eZ) { }
    }
    return ow + "x" + oh + " -> " + W + "x" + H + " (zoom x" + (Math.round(k * 1000) / 1000) + ")";
}

function cpOpBuild(args) {
    /* Maqsad kompozitsiyani template import qilinishidan OLDIN aniqlaymiz —
       import activeItem'ni o'zgartirib yuboradi. */
    var target = null;
    try {
        var ai = app.project.activeItem;
        if (ai && ai instanceof CompItem && !cpIsTemplateComp(ai.name)) target = ai;
    } catch (eAI) { }

    app.beginUndoGroup("Carousel Pro — Build " + args.style);
    try {
        cpEnsureTemplate();
        var srcName = "Dynamic Carousel " + args.style;
        var src = cpFindComp(srcName);
        if (!src) return cpErr(srcName + " kompozitsiyasi topilmadi");

        /* Asl kompozitsiyaga TEGMAYMIZ — nusxa olib, nusxani moslaymiz.
           Shunda qayta qurish har safar toza manbadan boshlanadi. */
        var workName = "Carousel Pro " + args.style;
        var old = cpFindComp(workName);
        if (old) old.remove();

        var work = src.duplicate();
        work.name = workName;

        var info = "nusxa";
        if (target) {
            info = cpReframe(work, target.width, target.height, args.fit || "width");
            try { work.frameRate = target.frameRate; } catch (eF) { }
            try { work.duration = target.duration; } catch (eD) { }
        }

        cpSetLayerEnabled(work, "Background", args.background ? true : false);
        cpSetLayerEnabled(work, "grain", args.grain ? true : false);

        if (target) {
            var i;
            for (i = target.numLayers; i >= 1; i--) {
                if (target.layer(i).comment === "CP_CAROUSEL") target.layer(i).remove();
            }
            var lyr = target.layers.add(work);
            lyr.moveToBeginning();
            lyr.comment = "CP_CAROUSEL";
            lyr.startTime = 0;
            lyr.property("ADBE Transform Group").property("ADBE Position")
               .setValue([target.width / 2, target.height / 2]);
            target.openInViewer();
            return cpOk('"comp":' + cpQ(work.name) +
                        ',"into":' + cpQ(target.name) +
                        ',"reframe":' + cpQ(info) +
                        ',"width":' + target.width + ',"height":' + target.height +
                        ',"fps":' + cpNum(target.frameRate) + ',"duration":' + cpNum(target.duration));
        }

        /* aktiv komp yo'q — nusxani ochamiz */
        work.openInViewer();
        return cpOk('"comp":' + cpQ(work.name) + ',"into":""' + ',"reframe":' + cpQ(info) +
                    ',"width":' + work.width + ',"height":' + work.height +
                    ',"fps":' + cpNum(work.frameRate) + ',"duration":' + cpNum(work.duration));
    } catch (e) {
        return cpErr(e.toString());
    } finally {
        app.endUndoGroup();
    }
}

/* Qurilgandan keyin ham fon/grain'ni yoqib-o'chirish uchun */
function cpOpToggleLayer(args) {
    app.beginUndoGroup("Carousel Pro — " + args.layer);
    try {
        var comp = cpFindComp(args.comp);
        if (!comp) return cpErr(args.comp + " topilmadi");
        if (!cpSetLayerEnabled(comp, args.layer, args.on ? true : false))
            return cpErr(args.layer + " qatlami bu uslubda yo'q");
        return cpOk('"layer":' + cpQ(args.layer) + ',"on":' + (args.on ? "true" : "false"));
    } catch (e) {
        return cpErr(e.toString());
    } finally {
        app.endUndoGroup();
    }
}


/* Kamera zoom'i effekt emas — CONTROLS tab'iga tushmaydi, shuning uchun alohida op. */
function cpOpZoom(args) {
    app.beginUndoGroup("Carousel Pro — kattalik");
    try {
        var comp = cpFindComp(args.comp);
        if (!comp) return cpErr(args.comp + " topilmadi");
        var base = 0;
        if (comp.comment && comp.comment.indexOf("CP_BASEZOOM:") === 0)
            base = parseFloat(comp.comment.substring(12));

        var i, L, zp, applied = 0;
        for (i = 1; i <= comp.numLayers; i++) {
            L = comp.layer(i);
            if (!(L instanceof CameraLayer)) continue;
            zp = L.property("ADBE Camera Options Group").property("ADBE Camera Zoom");
            if (!base || isNaN(base)) {
                base = zp.value;
                try { comp.comment = "CP_BASEZOOM:" + base; } catch (eC2) { }
            }
            zp.setValue(base * args.pct / 100);
            applied++;
        }
        if (!applied) return cpErr("kamera topilmadi");
        return cpOk('"pct":' + cpNum(args.pct));
    } catch (e) {
        return cpErr(e.toString());
    } finally {
        app.endUndoGroup();
    }
}

/* Panel "qayerga joylanadi" ni ko'rsatishi uchun */
function cpOpActive() {
    var n = "", w = 0, hh = 0;
    try {
        var ai = app.project.activeItem;
        if (ai && ai instanceof CompItem && !cpIsTemplateComp(ai.name)) {
            n = ai.name; w = ai.width; hh = ai.height;
        }
    } catch (e) { }
    return cpOk('"active":' + cpQ(n) + ',"width":' + w + ',"height":' + hh);
}

function cpOpControls(args) {
    var comp = cpFindComp(args.comp);
    if (!comp) return cpErr(args.comp + " topilmadi — avval STYLES dan birini quring");
    var groups = [], i, j, lyr, parade, one, fxList;
    for (i = 1; i <= comp.numLayers; i++) {
        lyr = comp.layer(i);
        if (!cpIsControlLayer(lyr.name)) continue;
        parade = cpEffectsOf(lyr);
        if (!parade || parade.numProperties === 0) continue;
        fxList = [];
        for (j = 1; j <= parade.numProperties; j++) {
            one = cpEffectJson(comp.name, lyr.name, parade.property(j), j);
            if (one !== "") fxList.push(one);
        }
        if (fxList.length) groups.push('{"layer":' + cpQ(lyr.name) + ',"items":' + cpArr(fxList) + "}");
    }
    return cpOk('"comp":' + cpQ(comp.name) + ',"groups":' + cpArr(groups));
}

function cpResolveProp(args) {
    var comp = cpFindComp(args.comp);
    if (!comp) throw new Error("Comp topilmadi: " + args.comp);
    var lyr = cpLayerByName(comp, args.layer);
    if (!lyr) throw new Error("Layer topilmadi: " + args.layer);
    var parade = cpEffectsOf(lyr);
    if (!parade) throw new Error("Effect yo'q: " + args.layer);
    var fx = null;
    try { fx = parade.property(args.fx); } catch (e) { }
    if (!fx && args.idx) { try { fx = parade.property(args.idx); } catch (e2) { } }
    if (!fx) throw new Error("Control topilmadi: " + args.fx);
    return fx.property(1);
}

function cpOpSet(args) {
    app.beginUndoGroup("Carousel Pro — " + args.fx);
    try {
        var p = cpResolveProp(args);
        if (args.type === "color") p.setValue([args.value[0], args.value[1], args.value[2], 1]);
        else if (args.type === "check") p.setValue(args.value ? 1 : 0);
        else if (args.type === "point") p.setValue([args.value[0], args.value[1]]);
        else p.setValue(args.value);
        return cpOk('"set":' + cpQ(args.fx));
    } catch (e) {
        return cpErr(e.toString());
    } finally {
        app.endUndoGroup();
    }
}

/* ── TEXT ── */

function cpTextComp(n) {
    return cpFindComp("Text " + n);
}

function cpOpReadTexts() {
    var out = [], n, comp, i, lyr, val;
    for (n = 1; n <= 10; n++) {
        comp = cpTextComp(n);
        val = "";
        if (comp) {
            for (i = 1; i <= comp.numLayers; i++) {
                lyr = comp.layer(i);
                if (lyr instanceof TextLayer) {
                    try { val = lyr.property("ADBE Text Properties").property("ADBE Text Document").value.text; } catch (e) { }
                    break;
                }
            }
        }
        out.push('{"n":' + n + ',"exists":' + (comp ? "true" : "false") + ',"text":' + cpQ(val) + "}");
    }
    return cpOk('"texts":' + cpArr(out));
}

function cpOpSetText(args) {
    app.beginUndoGroup("Carousel Pro — Text " + args.n);
    try {
        var comp = cpTextComp(args.n);
        if (!comp) return cpErr("Text " + args.n + " topilmadi");
        var i, lyr, doc;
        for (i = 1; i <= comp.numLayers; i++) {
            lyr = comp.layer(i);
            if (lyr instanceof TextLayer) {
                var tp = lyr.property("ADBE Text Properties").property("ADBE Text Document");
                doc = tp.value;
                doc.text = args.text;
                tp.setValue(doc);
                return cpOk('"n":' + args.n);
            }
        }
        return cpErr("Text " + args.n + " ichida matn qatlami yo'q");
    } catch (e) {
        return cpErr(e.toString());
    } finally {
        app.endUndoGroup();
    }
}

/* ── MEDIA ── */

function cpPlaceholderComp(n) {
    var c = cpFindComp("Placeholder " + n);
    if (c) return c;
    return cpFindComp("Placeholder " + n + " Precomp");
}

function cpOpReadMedia() {
    var out = [], n, comp, i, lyr, name, filled;
    for (n = 1; n <= 30; n++) {
        comp = cpPlaceholderComp(n);
        name = "";
        filled = false;
        if (comp) {
            for (i = 1; i <= comp.numLayers; i++) {
                lyr = comp.layer(i);
                if (lyr.comment === "CP_MEDIA") { name = lyr.name; filled = true; break; }
            }
        }
        out.push('{"n":' + n + ',"exists":' + (comp ? "true" : "false") +
            ',"filled":' + (filled ? "true" : "false") + ',"name":' + cpQ(name) + "}");
    }
    return cpOk('"slots":' + cpArr(out));
}

function cpImportFootage(path) {
    var f = new File(path);
    if (!f.exists) throw new Error("Fayl topilmadi: " + path);
    var io = new ImportOptions(f);
    if (io.canImportAs(ImportAsType.FOOTAGE)) io.importAs = ImportAsType.FOOTAGE;
    return app.project.importFile(io);
}

function cpSetMediaInner(args) {
    var comp = cpPlaceholderComp(args.n);
    if (!comp) return cpErr("Placeholder " + args.n + " topilmadi");
    {

        // remove a previously placed media layer, restore hidden originals
        var i;
        for (i = comp.numLayers; i >= 1; i--) {
            if (comp.layer(i).comment === "CP_MEDIA") comp.layer(i).remove();
        }
        for (i = 1; i <= comp.numLayers; i++) {
            if (comp.layer(i).comment === "CP_HIDDEN") { comp.layer(i).enabled = true; comp.layer(i).comment = ""; }
        }

        var item = cpImportFootage(args.path);
        var lyr = comp.layers.add(item);
        lyr.moveToBeginning();
        lyr.comment = "CP_MEDIA";
        lyr.name = String(args.path).split("/").pop();

        // fit to fill (cover)
        var sw = item.width, sh = item.height;
        if (sw > 0 && sh > 0) {
            var s = Math.max(comp.width / sw, comp.height / sh) * 100;
            lyr.property("ADBE Transform Group").property("ADBE Scale").setValue([s, s]);
            lyr.property("ADBE Transform Group").property("ADBE Position").setValue([comp.width / 2, comp.height / 2]);
        }
        lyr.startTime = 0;
        try { if (lyr.outPoint < comp.duration) lyr.outPoint = comp.duration; } catch (eOut) { }

        // hide the original placeholder graphics underneath
        for (i = 2; i <= comp.numLayers; i++) {
            if (comp.layer(i).enabled) { comp.layer(i).enabled = false; comp.layer(i).comment = "CP_HIDDEN"; }
        }

        return cpOk('"n":' + args.n + ',"name":' + cpQ(lyr.name));
    }
}

function cpOpSetMedia(args) {
    app.beginUndoGroup("Carousel Pro — Media " + args.n);
    try {
        return cpSetMediaInner(args);
    } catch (e) {
        return cpErr(e.toString());
    } finally {
        app.endUndoGroup();
    }
}

function cpOpClearMedia(args) {
    app.beginUndoGroup("Carousel Pro — Clear " + args.n);
    try {
        var comp = cpPlaceholderComp(args.n);
        if (!comp) return cpErr("Placeholder " + args.n + " topilmadi");
        var i;
        for (i = comp.numLayers; i >= 1; i--) {
            if (comp.layer(i).comment === "CP_MEDIA") comp.layer(i).remove();
        }
        for (i = 1; i <= comp.numLayers; i++) {
            if (comp.layer(i).comment === "CP_HIDDEN") { comp.layer(i).enabled = true; comp.layer(i).comment = ""; }
        }
        return cpOk('"n":' + args.n);
    } catch (e) {
        return cpErr(e.toString());
    } finally {
        app.endUndoGroup();
    }
}

function cpOpPickFiles() {
    var files = File.openDialog("Rasm yoki video tanlang", "*.*", true);
    if (!files) return cpOk('"paths":[]');
    var out = [], i;
    if (!(files instanceof Array)) files = [files];
    for (i = 0; i < files.length; i++) out.push(cpQ(files[i].fsName));
    return cpOk('"paths":' + cpArr(out));
}

function cpOpFillAll(args) {
    app.beginUndoGroup("Carousel Pro — Fill All");
    try {
        var paths = args.paths, done = 0, i;
        for (i = 0; i < paths.length && i < 30; i++) {
            var r = cpSetMediaInner({ n: (args.start || 1) + i, path: paths[i] });
            if (r.indexOf('"ok":true') >= 0) done++;
        }
        return cpOk('"filled":' + done);
    } catch (e) {
        return cpErr(e.toString());
    } finally {
        app.endUndoGroup();
    }
}

function cpOpOpenTemplate() {
    try {
        cpRequireCompatibleTemplate();
        var f = cpTemplateFile();
        if (!f.exists) return cpErr("Template topilmadi: " + f.fsName);
        app.open(f);
        return cpOk('"opened":' + cpQ(f.fsName));
    } catch (e) {
        return cpErr(e.toString());
    }
}

function cpOpGoto(args) {
    try {
        var comp = cpFindComp(args.comp);
        if (!comp) return cpErr(args.comp + " topilmadi");
        comp.openInViewer();
        comp.time = args.time;
        return cpOk('"time":' + cpNum(args.time));
    } catch (e) {
        return cpErr(e.toString());
    }
}

// ─────────────────────────────────────────── dispatcher

function CP_run(enc) {
    var args, res;
    try {
        args = eval("(" + decodeURIComponent(enc) + ")");
    } catch (e) {
        cpLog("PARSE XATO: " + e.toString() + " | raw=" + String(enc).substring(0, 200));
        return cpErr("Argument parse: " + e.toString());
    }
    cpLog("-> " + args.op + " " + decodeURIComponent(enc).substring(0, 200));
    try {
        res = CP_dispatch(args);
        cpLog("<- " + args.op + " " + String(res).substring(0, 300));
        return res;
    } catch (eRun) {
        cpLog("!! " + args.op + " XATO: " + eRun.toString());
        return cpErr(eRun.toString());
    }
}

function CP_ping() { return cpSelfTest(); }

function CP_dispatch(args) {
    try {
        switch (args.op) {
            case "init": return cpOpInit(args);
            case "env": return cpOpEnv();
            case "build": return cpOpBuild(args);
            case "toggleLayer": return cpOpToggleLayer(args);
            case "zoom": return cpOpZoom(args);
            case "active": return cpOpActive();
            case "controls": return cpOpControls(args);
            case "set": return cpOpSet(args);
            case "readTexts": return cpOpReadTexts();
            case "setText": return cpOpSetText(args);
            case "readMedia": return cpOpReadMedia();
            case "setMedia": return cpOpSetMedia(args);
            case "clearMedia": return cpOpClearMedia(args);
            case "pickFiles": return cpOpPickFiles();
            case "fillAll": return cpOpFillAll(args);
            case "openTemplate": return cpOpOpenTemplate();
            case "goto": return cpOpGoto(args);
            case "ping": return cpOk('"info":' + cpQ(cpSelfTest()));
            default: return cpErr("Noma'lum operatsiya: " + args.op);
        }
    } catch (e) {
        return cpErr(e.toString());
    }
}

try { cpSelfTest(); } catch (eBoot) { }
