# HUMBLE Carousel — After Effects CEP panel

HUMBLE Carousel is a free After Effects panel with 10 ready-made carousel styles.

-------------------------------------------------------------------------

## Installation
================

Copy the `HUMBLE_Carousel_1.0.3` folder to:

**Windows**

	C:\Program Files (x86)\Common Files\Adobe\CEP\extensions

**macOS**

	~/Library/Application Support/Adobe/CEP/extensions/




Open After Effects → Window → Extensions → HUMBLE Carousel.

-------------------------------------------------------------------------

## Compatibility
=================

The panel manifest targets After Effects 2022 and newer. 

-------------------------------------------------------------------------

## Social

- Instagram: https://www.instagram.com/_humble.y_/
- YouTube: https://www.youtube.com/@humbleae

-------------------------------------------------------------------------

HUMBLE<3
